### Command

Phase starts at the beginning of the players turn

- In a normal game you would be given Command Points, we will not use CP in our games because of their added complexity
-  If a unit is below half strength (starting strength of 1 or if the # of models in a unit are less than half of its Starting Strength) you have to check for battle-shock
	- Roll 2D6. If the result is greater than or equal to the best Leadership characteristic in that unit, the test is passed
	- If the check is failed:
		- The Objective Control characteristic of all of its models is 0
		- If it Falls Back, you must take a Desperate Escape Test for every model in that unit
		- Its controlling player cannot use Stratagems to affect that unit (if using CP)
### Movement

For each unit the player can either choose to remain stationary or move.

- If the the unit is within Engagement Range to enemy units (1 inch horizontal 5 inch vertical of each other) they have to either remain stationary or fall back
- If the unit is not within Engagement Range the unit can make a Normal move, Advance, or Remain Stationary
- Normal Move: Check the stat sheet for the unit. Move up to a distance in inches less than or equal to its Move (M) characteristic.
- Advance Move: Models move M+D6 in inches. The units that make this move cannot shoot or charge this turn

In both above movements, you are not allowed to be in Engagement Range

- Fallback Move: Unit moves up to M inches but it can't shoot or declare a charge in the same turn
- Desperate Escape Tests occur when the unit is Battle-Shocked. Roll a D6, on a 1 or 2 a model from that unit is destroyed
### Shooting

In this phase the player can select those units and shoot at an eligible target.

Conditions:

- The unit has not Advanced this turn
- The unit has not Fell Back this turn
- Eligible targets have to have at least one Visible model ([[Core Rules and Concepts]])
- Models with more than one ranged weapon can shoot them at the same or different targets, but models cannot split attacks from the same weapon across more than one target
- Models in the same unit can shoot at different targets
- Units cannot shoot while in Engagement Range of any enemy units
- Units cannot shoot at targets within Engagement Range of friendly units

Once those conditions are met, the unit can attack its target.

- When a model shoots a weapon, it makes a number of attacks equal to that weapon’s Attacks characteristic
- Resolve all attacks against one unit before resolving attacks against any other unit.
- If a weapon was in range and its target was visible when selected, that weapon’s attacks can always be made.

When it comes to actually making an attack, take a look at [[Combat Phases]] to see how that is done.

### Charge

The purpose of this phase is used to move units closer to the enemy to engage in close range combat.

A unit is eligible to charge if: 

- The unit did not Advance or Fell Back this turn
- The unit is not within engagement Range of any enemy models
- The unit is not an Aircraft unit

Once an eligible unit is picked, the charging can commence one unit at a time:
- Charge Roll: 2D6
- Targets of a charge must be with in 12 inches but do not have to be visible ([[Core Rules and Concepts]])
- If the distance rolled is insufficient to move within Engagement Range of all targets while maintaining Unit Coherency (visit [[Core Rules and Concepts]]), the charge fails
- Cannot move within Engagement Range of any unit that was not a target of the charge
- If the charge is successful, each model makes a Charge move less than or equal to the Charge roll, and must move into base-to-base contact with an enemy model if possible.

### Fight

In this phase close combat can take place. MELEE WEAPONS ONLY.

A unit is eligible to fight when:

- It is within Engagement Range of one or more enemy units.
- It made a Charge move this turn

The Fight phase is split into the Fight First and the Remaining Combats. Units with Fights First go first in combat and then every other eligible unit goes after that. 

- Fights First only apply if every model in the unit has this ability

When you select a unit to fight, it first Piles In, then its models make melee attacks, then the unit Consolidates

1.  Pile in
	- Used to move into Engagement Range
	- Pile in Movement: Up to 3 inches
	- Every model that moves must end closer to the closest enemy model, and in base-to-base contact with an enemy model if possible. The unit must end in Unit Coherency and within Engagement Range of at least one enemy unit (or no models can Pile In).
2. Make Melee Attacks
	- Fight Eligibility:
		- A model can fight if it is within Engagement Range of an enemy unit
		- A model can fight if it is in base-to-base contact with another model from its own unit that is itself in base-to-base contact with an enemy unit.
	- Select Targets:
		- Select targets for all attacks before any are resolved.
		- Attacking model must either be within Engagement Range of an enemy unit to target it, or in base-to-base contact with another model in its unit that is itself in base-to-base contact with that enemy unit.
	- Make Attacks
		- Resolve all attacks against one unit before moving onto the next.
		- Resolve all attacks with the same weapon profile before resolving any made with a different weapon profile
		- All attacks declared against a target unit are resolved, even if no models in that unit remain within Engagement Range
		- Check out [[Combat Phases]] to see how to make attacks
3. Consolidate
	- Used for moving units closer after combat
	- Consolidation Move: Up to 3 inches
	- Every model that moves must end closer to the closest enemy model, and in base-to-base contact with an enemy model if possible. The unit must end in Unit Coherency and within Engagement Range of at least one enemy unit if possible.
	- If the above is not possible, each model can move towards the closest objective marker, but this must result in the unit being within range of it and in Unit Coherency
		- If the above is also not possible, no models can Consolidate.