This is a simple players/rules guide for a slightly dumbed down 10th edition of Warhammer 40k. I took the majority of the rules from the official guide. It is listed when the rule is not from the official source. The contents of this guide are shown below:

1. [[Core Rules and Concepts]]
	- This introduces the basic rules, terms, and concepts of the game
2. [[Turn Phases]]
	- Shows the rules of a player turn in detail
3. [[Combat Phases]]
	- Explains the rules of ranged and melee combat in 40k