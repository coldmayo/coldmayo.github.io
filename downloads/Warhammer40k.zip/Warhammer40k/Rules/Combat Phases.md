These steps are taken to properly engage in combat in game

1. Hit Roll
	- Hit Roll for a Ranged Attack: A hit is scored if the D6 result equals or exceeds that attack’s BS
	- Hit Roll for a Melee Attack: A hit is scored if the D6 result equals or exceeds that attack’s WS
	- A Critical Hit is an unmodified hit roll of 6. It is always successful
	- A Hit roll can never be modified by more than -1 or +1
2. Wound Roll
	- A wound roll is done for every hit roll that scores. Roll a D6 to see if the attack successfully wounds the target unit
		- The result needed is determined by comparing the attacks Strength (S) and targets Toughness (T) characteristic. See below ![[rolls.png]]
	- A Critical Wound is an unmodified Wound roll of 6. It is always successful.
	- An unmodified Wound roll of 1 always fails
	- A Wound roll can never be modified by more than -1 or +1
3. Allocate Attack
	- If an attack successfully wounds the target unit, the player controlling the target unit allocates that attack to one model in the target unit
	- If a model in the target unit has already lost any wounds or had other attacks allocated to it this phase, the attack must be allocated to that model.
4. Saving Throw
	- The player controlling the target makes an armor saving throw using the model's Save (Sv) characteristic
	- To make a Saving Throw: Roll one D6 and modify by the attack’s AP. If the result is less than the Save of the model being rolled for, the saving throw is failed and that model suffers damage. Otherwise, that attack is saved.
	- An unmodified saving throw of 1 always fails.
	- A saving throw can never be improved by more than +1.
	- Some models have invulnerable saves that can be used instead (up to the player)
		- The only difference this makes is that the save is never impacted by an attacks AP
5. Inflict Damage
	- The damage inflicted is equal to the Damage (D) characteristic of the attack
	- A model loses one wound for each point of damage it suffers. If a model’s wounds are reduced to 0 or less, it is destroyed and removed from play
	- If a model is destroyed by an attack, any excess damage inflicted by that attack is lost.

Example:
![[exampleAttack.png]]